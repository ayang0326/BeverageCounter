var apikey = '622e9137dced170e8c83a238';
var url = 'https://ayangdailydrink-3299.restdb.io/rest/dailydrinkcount';
var arrDailyDrinkData = [
    {name: "Coffee", cups: 0, ammount: 0, order: 0},
    {name: "Water", cups: 0, ammount: 0, order: 1},
    {name: "Tea", cups: 0, ammount: 0, order: 2},
    {name: "Juice", cups: 0, ammount: 0, order: 3},
    {name: "total", cups: 0, ammount: 0, order: 4}
];

var visible = '';


//Variables --------------------------------

$('#drinkDisplayCoffee').hide();
$('#drinkDisplayJuice').hide();
$('#drinkDisplayTea').hide();
$('#drinkDisplayWater').hide();


//drink ammount function --------------------------------
$('#hundredMl').click(function(){
    arrDailyDrinkData[4].ammount +=100;
    switch (visible){
      case 'c': arrDailyDrinkData[0].ammount +=100;
      break;
      case 'w': arrDailyDrinkData[1].ammount +=100;
      break;
      case 't': arrDailyDrinkData[0].ammount +=100;
      break;
      case 'j': arrDailyDrinkData[1].ammount +=100;
      break;
    }
    console.log(arrDailyDrinkData);
});
$('#twoFiftyMl').click(function(){
  arrDailyDrinkData[4].ammount +=250;
  switch (visible){
    case 'c': arrDailyDrinkData[0].ammount +=250;
    break;
    case 'w': arrDailyDrinkData[1].ammount +=250;
    break;
    case 't': arrDailyDrinkData[0].ammount +=250;
    break;
    case 'j': arrDailyDrinkData[1].ammount +=250;
    break;
  }
  console.log(arrDailyDrinkData);
});
$('#sixHundredMl').click(function(){
  arrDailyDrinkData[4].ammount +=600;
  switch (visible){
    case 'c': arrDailyDrinkData[0].ammount +=600;
    break;
    case 'w': arrDailyDrinkData[1].ammount +=600;
    break;
    case 't': arrDailyDrinkData[0].ammount +=600;
    break;
    case 'j': arrDailyDrinkData[1].ammount +=600;
    break;
  }
  console.log(arrDailyDrinkData);
});

$('#eightFiftyMl').click(function(){
  arrDailyDrinkData[4].ammount +=850;
  switch (visible){
    case 'c': arrDailyDrinkData[0].ammount +=850;
    break;
    case 'w': arrDailyDrinkData[1].ammount +=850;
    break;
    case 't': arrDailyDrinkData[0].ammount +=850;
    break;
    case 'j': arrDailyDrinkData[1].ammount +=850;
    break;
  }

  console.log(arrDailyDrinkData);
});
$('#litre').click(function(){
  arrDailyDrinkData[4].ammount +=1000;
  switch (visible){
    case 'c': arrDailyDrinkData[0].ammount +=1000;
    break;
    case 'w': arrDailyDrinkData[1].ammount +=1000;
    break;
    case 't': arrDailyDrinkData[0].ammount +=1000;
    break;
    case 'j': arrDailyDrinkData[1].ammount +=1000;
    break;
  }
  console.log(arrDailyDrinkData);
});
//--------------------------------

//dropdown-----------
function myFunction() {
    document.getElementById("differentDrinks").classList.toggle("show");
}
// Close the dropdown menu if the user clicks outside of it
window.onclick = function(event) {
    if (!event.target.matches('.dropbtn')) {
      var dropdowns = document.getElementsByClassName("drinkContent");
      var i;
      for (i = 0; i < dropdowns.length; i++) {
        var openDropdown = dropdowns[i];
        if (openDropdown.classList.contains('show')) {
          openDropdown.classList.remove('show');
        }
}}}
 // --------------------------------

$('#coffee').click(function(){
    $('#drinkDisplayDrink').hide();
    $('#drinkDisplayJuice').hide();
    $('#drinkDisplayTea').hide();
    $('#drinkDisplayWater').hide();
    $('#drinkDisplayCoffee').show();
    visible ='c';
});

$('#water').click(function(){
  $('#drinkDisplayDrink').hide();
  $('#drinkDisplayJuice').hide();
  $('#drinkDisplayTea').hide();
  $('#drinkDisplayCoffee').hide();
  $('#drinkDisplayWater').show();
  visible ='w';
});

$('#tea').click(function(){
    $('#drinkDisplayDrink').hide();
    $('#drinkDisplayJuice').hide();
    $('#drinkDisplayCoffee').hide();
    $('#drinkDisplayWater').hide();
    $('#drinkDisplayTea').show();
    visible ='t';
});

$('#juice').click(function(){
    $('#drinkDisplayDrink').hide();
    $('#drinkDisplayCoffee').hide();
    $('#drinkDisplayTea').hide();
    $('#drinkDisplayWater').hide();
    $('#drinkDisplayJuice').show();
    visible ='j';
});



function addAnimal(item, url, apikey){
  var settings = {
      "async": true,
      "crossDomain": true,
      "url": url,
      "method": "POST",
      "headers": {
          "content-type": "application/json",
          "x-apikey": apikey,
          "cache-control": "no-cache"
      },
      "processData": false,
      "data": JSON.stringify(item)
  }
  
  $.ajax(settings).done(function (response) {
      console.log('Item successfully added');
      console.log(response);
  });
}

$('#hundredMl').click(function(){
  console.log('submitted');
  var tempAnimal = {Name: $('#name'), Cups: $('#cups'), Amount: $('#amount'), Date: $('#date').val()};
  addAnimal(tempAnimal, url, apikey);
})
addAnimal(url,apikey);

/*
var d = 0;
//Check visible div for data input --------------------------------
function checkVisible(d){
if (cVisible == true){
  d = 0;
  ammountSpecific();
}
else if (wVisible == true){
  d = 1;
  ammountSpecific();
}
else if (tVisible == true){
  d = 2;
  ammountSpecific();
}
else if (tVisible == true){
  d = 3;
  ammountSpecific();
}
}


//Check visible div for data input --------------------------------

function ammountSpecific(yes){
  let d = yes;
  console.log(d);
  $('#hundredMl').click(function(){
    arrDailyDrinkData[d].ammount = arrDailyDrinkData[d].ammount +100;
  });
  $('#twoFiftyMl').click(function(){
    arrDailyDrinkData[d].ammount = arrDailyDrinkData[d].ammount +250;
  });
  $('#sixHundredMl').click(function(){
    arrDailyDrinkData[d].ammount = arrDailyDrinkData[d].ammount +600;
  });
  $('#eightFiftyMl').click(function(){
    arrDailyDrinkData[d].ammount = arrDailyDrinkData[d].ammount +850;
  });
  $('#litre').click(function(){
    arrDailyDrinkData[d].ammount = arrDailyDrinkData[d].ammount +1000;
  });
  yes = undefined;

}

//--------------------------------
*/